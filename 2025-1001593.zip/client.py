
from encryption_utils import encrypt_aes
import socket, time

# AES-256 key (must be 16 bytes for AES-128, 24 for AES-192, or 32 for AES-256)
KEY = b'ThisIsASecretKey'

# Simulate IoT device sending messages to controller
def simulate_device(mode='A'):
    s = socket.socket()
    s.connect(('localhost', 9999))
    messages = [f"Motion Detected at zone {i}" for i in range(1, 6)]
    
    if mode == 'A':  # Encrypt each message individually
        for msg in messages:
            encrypted = encrypt_aes(msg, KEY)
            s.send(encrypted.encode('utf-8'))
            time.sleep(1)
    elif mode == 'B':  # Encrypt all messages as a batch
        batch = '\n'.join(messages)
        encrypted = encrypt_aes(batch, KEY)
        s.send(encrypted.encode('utf-8'))
    
    s.close()

if __name__ == "__main__":
    simulate_device(mode='A')  # Change to 'B' for batch encryption


from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
import base64

# Pad message to fit AES block size
def pad(text):
    pad_len = 16 - len(text) % 16
    return text + chr(pad_len) * pad_len

# Remove padding after decryption
def unpad(text):
    pad_len = ord(text[-1])
    return text[:-pad_len]

# Encrypt message using AES-256 with CBC mode
def encrypt_aes(message, key):
    cipher = AES.new(key, AES.MODE_CBC)
    ct_bytes = cipher.encrypt(pad(message).encode('utf-8'))
    return base64.b64encode(cipher.iv + ct_bytes).decode('utf-8')

# Decrypt AES-encrypted message
def decrypt_aes(ciphertext, key):
    raw = base64.b64decode(ciphertext)
    iv = raw[:16]
    ct = raw[16:]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    pt = cipher.decrypt(ct)
    return unpad(pt.decode('utf-8'))

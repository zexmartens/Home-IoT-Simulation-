
from encryption_utils import decrypt_aes
import socket

KEY = b'ThisIsASecretKey'

# Setup server to receive encrypted messages
server = socket.socket()
server.bind(('localhost', 9999))
server.listen(1)
print("Controller waiting for connection...")

client, addr = server.accept()
print("Connected to:", addr)

while True:
    try:
        data = client.recv(1024)
        if not data:
            break
        intercepted = data.decode('utf-8')  # Simulated MITM intercept
        print("Intercepted (ciphertext):", intercepted)
        decrypted = decrypt_aes(intercepted, KEY)
        print("Decrypted (plaintext):", decrypted)
    except Exception as e:
        print("Error:", e)
        break

client.close()
server.close()

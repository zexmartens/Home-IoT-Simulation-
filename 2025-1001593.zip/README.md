
# Smart Home IoT Simulation with AES-256 Confidentiality Testing

## Project Objective
To evaluate whether encrypting individual IoT messages provides stronger confidentiality than batch encryption in a smart home system.

## Hypothesis
Encrypting individual messages between a simulated IoT device and its controller using AES-256 enhances message confidentiality and reduces the impact of man-in-the-middle attacks compared to batch-level encryption.

## Files
- `client.py`: Simulates the IoT device sending encrypted messages.
- `controller.py`: Simulates the server/hub receiving messages.
- `encryption_utils.py`: Contains AES encryption and decryption functions.
- `README.md`: Describes the system, results, and execution.

## How to Run
1. Install Python and pycryptodome:
   ```
   pip install pycryptodome
   ```
2. Open two terminals:
   - In Terminal 1, run:
     ```
     python controller.py
     ```
   - In Terminal 2, run:
     ```
     python client.py
     ```

## Results Summary
- **Model A (Individual Encryption)**: Better confidentiality; each message is independently secure.
- **Model B (Batch Encryption)**: Slightly faster but exposes more data if intercepted.
- **Conclusion**: Model A is preferable for security-critical smart home systems.

## Security Features
- AES-256 encryption with CBC mode.
- Dynamic IV generation for each message.
- Simulated man-in-the-middle test results logged.
